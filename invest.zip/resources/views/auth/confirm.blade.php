@extends('layouts.default')

@section('content')

<div class="container">
    <h1 class="my-4">{{ $message }}</h1>
</div>
@endsection