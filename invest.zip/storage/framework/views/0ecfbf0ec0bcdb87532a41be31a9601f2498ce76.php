<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mt-4 mb-3">Изменение Кошелька</h1>
    <div class="row">
        <div class="col-lg-8 mb-4">
            <?php if(session()->has('errors')): ?>
             <h1 style="color:red">Данные введены неверно</h1>
            <?php elseif(isset($error)): ?>
            <h1 style="color:red"><?php echo e($error); ?></h1>
            <?php endif; ?>
            <form method="post">
                <?php echo e(csrf_field()); ?>

                <div class="control-group form-group">
                    <div class="controls">
                        <label>Пароль:</label>
                        <input type="password" class="form-control" name="password" required>
                        <p class="help-block"></p>
                    </div>
                    <div class="controls">
                        <label>Новый кошелек:</label>
                        <input type="password" class="form-control" name=" wallet" required>
                        <p class="help-block"></p>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Изменить кошелек</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>