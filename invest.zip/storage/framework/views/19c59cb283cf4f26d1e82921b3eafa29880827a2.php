<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="mt-4 mb-3"><?php echo e($tariff->title); ?></h1>
    <div class="row">
        <div class="col-lg-12 mb-4">
            <form action="https://perfectmoney.is/api/step1.asp" method="post" target="_blank" id="no_ajax">				
				<div class="control-group form-group">
                    <div class="controls">
                        <label>Название тарифа:</label>
                        <input type="text" class="form-control" value="<?php echo e($tariff->title); ?>" disabled>
                    </div>
                </div>
                <div class="control-group form-group">
                    <div class="controls">
                        <label>Период инвестиции:</label>
                        <input type="text" class="form-control" value="<?php echo e($tariff->hour); ?> ч." disabled>
                    </div>
                </div>
                <div class="control-group form-group">
                    <div class="controls">
                        <label>Процентная ставка:</label>
                        <input type="text" class="form-control" value="<?php echo e($tariff->percent); ?> %" disabled>
                    </div>
                </div>
				<input type="hidden" name="PAYEE_ACCOUNT" value="U17905778">
				<input type="hidden" name="PAYEE_NAME" value="Оплата тарифа # <?php echo e($tariff->id); ?>">
				<div class="control-group form-group">
                    <div class="controls">
                        <label>Сумма:</label>
                        <input type="number" min="<?php echo e($tariff->min); ?>" class="form-control" value="<?php echo e($tariff->min); ?>" name="PAYMENT_AMOUNT">
                    </div>
                </div>
                
                <input type="hidden" name="PAYMENT_UNITS" value="USD">
                <input type="hidden" name="STATUS_URL" value=<?php echo e(route('perfectMoney')); ?>>
                <input type="hidden" name="PAYMENT_URL" value="https://www.myshop.com/cgi-bin/chkout1.cgi">
                <input type="hidden" name="NOPAYMENT_URL"  value="https://www.myshop.com/cgi-bin/chkout2.cgi">
                <input type="hidden" name="PAYMENT_ID" value="<?php echo e($tariff->id); ?>','<?php echo e($userId); ?>">
				<button type="sumbit" class="btn btn-primary">Перейти к оплате</button>
			</form>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>