<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-header"><h1>История</h1></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12">
                         <?php if(!$history): ?>
                            <p>История пуста</p>
                         <?php else: ?>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Логин</th>
                                        <th>E-mail</th>
                                        <th>Инвестиция</th>
                                        <th>Прибль</th>
                                        <th>Процент</th>
                                        <th>Начало инвестиции</th>
                                        <th>Конец инвестиции</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->login); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo e($val->sumin); ?>$</td>
                                            <td><?php echo e($val->sumout); ?>$</td>
                                            <td><?php echo e($val->percent); ?>%</td>
                                            <td><?php echo e($val->created_at); ?></td>
                                            <td><?php echo e($val->investFinish); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                         
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>