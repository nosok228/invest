<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mt-4 mb-3">Аккаунт></h1>
    <div class="row">
        <div class="col-lg-8 mb-4">
        <?php if(isset($notice)): ?>
           <h2 style="color:red"><?php echo e($notice); ?>

        <?php endif; ?>
        <?php if(isset($success)): ?>
           <h2 style="color:green"><?php echo e($success); ?></h2>
        <?php endif; ?>
        </div>
        <?php if(\Illuminate\Support\Facades\Auth::user()->status): ?>
        <h3>Ваша ссылка для приглашения рефералов: <?php echo e(route('register', ['id' => \Illuminate\Support\Facades\Auth::user()->login])); ?>

            <br> <br> <br> <br> <br> <br>
            <p> Настройки аккаунта <br> <br>
                <a class="btn btn-primary" href = "<?php echo e(route('changePassword')); ?>">Изменить пароль</a>
                <a class="btn btn-primary" href = "<?php echo e(route('changeWallet')); ?>">Изменить кошелек</a>
            </p>
            <br> <br> <br> <br> <br> <br>
               <form method="POST">
                   <?php echo e(csrf_field()); ?>

                   <label for = "sum">Средства которые вы можете вывести</label>
                   <br>
                   <input type = "text" value = "<?php echo e($wallet); ?>" readonly id = "sum" name = "sum">
                   <button type="submit" class="btn btn-primary">Запросить вывод денег</button>
               </form>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>