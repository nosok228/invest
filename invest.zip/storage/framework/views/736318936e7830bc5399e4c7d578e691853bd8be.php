<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-header"></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12">
                         <?php if(!isset($list)): ?> 
                            <p>Список инвестиций пуст</p>
                         <?php else: ?> 
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Номер вклада</th>
                                        <th>Дата старта</th>
                                        <th>Дата завершения</th>
                                        <th>Сумма</th>
                                        <th>Получаете</th>
                                        <th>Процент</th>
                                        <th>Логин</th>
                                        <th>E-mail</th>
                                        <th>Статус</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php echo e($val); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>