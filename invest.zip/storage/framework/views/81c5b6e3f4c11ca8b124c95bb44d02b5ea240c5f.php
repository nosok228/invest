<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-lg-12 mb-4">
            <?php if(empty($list)): ?>
            	<p>Список инвестиций пуст</p>
             <?php else: ?>
            	<table class="table table-bordered">
            		<thead>
            			<tr>
            				<th>Дата старта</th>
            				<th>Дата завершения</th>
            				<th>Сумма</th>
            				<th>Получаете</th>
            				<th>Процент</th>
                            <th>Статус</th>
            			</tr>
            		</thead>
            		<tbody>
		            	<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            		<tr>
								<?php echo e($val); ?>

							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				<?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>