<?php $__env->startSection('content'); ?>

<div class="container">
        <h1 class="mt-4 mb-3">История</h1>
        <div class="row">
            <div class="col-lg-12 mb-4">
                 <?php if(!$list): ?>
                    <p>История пуста</p>
                
                    <?php elseif(isset($list['payments'])): ?>
                    <h1>Свои платежи</h1>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Начало инвестиции</th>
                                <th>Конец инвестиции</th>
                                <th>Инвестиция</th>
                                <th>Прибыль</th>
                                <th>Процент</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $list['payments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($val->investStart); ?></td>
                                    <td><?php echo e($val->investFinish); ?></td>
                                    <td><?php echo e($val->sumin); ?>$</td>
                                    <td><?php echo e($val->sumout); ?>$</td>
                                    <td><?php echo e($val->percent); ?>%</td>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                 <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>