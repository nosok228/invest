<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="container-fluid">
        <div class="card mb-3">
            <div class="card-header">Заявки на вывод по тарфиам</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12">
                        <?php if(!$requests): ?>
                            <p>Список заявок на вывод по тарфиам пуст</p>
                        <?php else: ?>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Номер вклада</th>
                                        <th>Дата</th>
                                        <th>Сумма</th>
                                        <th>Логин</th>
                                        <th>Email</th>
                                        <th>Кошелек</th>
                                        <th>Действия</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($request->id); ?></td>
                                            <td><?php echo e($request->created_at); ?></td>
                                            <td><?php echo e($request->sum); ?>$</td>
                                            <td><?php echo e($request->login); ?></td>
                                            <td><?php echo e($request->email); ?></td>
                                            <td><?php echo e($request->wallet); ?></td>
                                            <td>
                                                <form method="post">
                                                    <?php echo e(csrf_field()); ?>

                                                    <input type="hidden" name="type" value="tariff">
                                                    <input type="hidden" name="id" value="<?php echo e($request->user_id); ?>">
                                                    <button type="submit" class="btn btn-success">Выплатить</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                         <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
         
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>