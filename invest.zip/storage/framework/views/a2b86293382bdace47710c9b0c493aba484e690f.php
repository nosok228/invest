<?php $__env->startSection('content'); ?>

<form method="POST">
    <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <label for="title">Заголовок</label>
          <input type="text" class="form-control" id="title" name = "title" value = "<?php echo e($tarif->title); ?>" required>
        </div>
        <div class="form-group">
                <label for="description">Описание</label>
                <textarea class="form-control" id="description" name = "description" rows="3" required><?php echo e($tarif->description); ?></textarea>
        </div>
        <div class="form-group">
          <label for="hour">Продолжительность тарифа</label>
          <input type="number"class="form-control" id="hour" name = "hour" value = "<?php echo e($tarif->hour); ?>" required>
          </input>
        </div>
        <div class="form-group">
                <label for="percent">Процент</label>
                <input type="number"class="form-control" id="percent" name = "percent" value = "<?php echo e($tarif->percent); ?>" required>
                </input>
              </div>
              <div class="form-group">
                    <label for="min">Минимальный платеж</label>
                    <input type="number"class="form-control" id="min" name = "min" value = "<?php echo e($tarif->min); ?>" required>
                    </input>
                </div>
            <div class="form-group">
                        <label for="max">Максимальный платеж</label>
                        <input type="number"class="form-control" id="max" name = "max" value = "<?php echo e($tarif->max); ?>" required>
                        </input>
                      </div>
                      <input class="btn btn-primary" type="submit" value="Редактировать">
      </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>