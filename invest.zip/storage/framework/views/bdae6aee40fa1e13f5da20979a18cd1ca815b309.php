<?php $__env->startSection('content'); ?>

                 <?php if(!$tarifs): ?>
                    <h3 style="color:red">Список тарифов пуст. <a href = "<?php echo e(route('addTarif')); ?>"> Добавить? </a></h3>

                 <?php else: ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Заголовок</th>
                                <th>Описание</th>
                                <th>Количество часов</th>
                                <th>Процент</th>
                                <th>Минимальный платеж</th>
                                <th>Максимальный платеж</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tarifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tarif->title); ?></td>
                                    <td><?php echo e($tarif->description); ?></td>
                                    <td><?php echo e($tarif->hour); ?></td>
                                    <td><?php echo e($tarif->percent); ?>%</td>
                                    <td><?php echo e($tarif->min); ?>$</td>
                                    <td><?php echo e($tarif->max); ?>$</td>
                                    <td><a href = "<?php echo e(route('editTarif', ['id' => $tarif->id])); ?>">Редактировать</a> || <a href = "<?php echo e(route('deleteTarif', ['id' => $tarif->id])); ?>">Удалить</a></td>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>