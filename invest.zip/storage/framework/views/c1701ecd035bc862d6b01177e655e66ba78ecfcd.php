<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="my-4">Тарифы</h1>
    <div class="row">
        <?php $__currentLoopData = $tarifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 mb-4">
                <div class="card h-100">
                    <h3 class="card-header"><?php echo e($tarif->title); ?></h3>
                    <div class="card-body">
                        <div class="display-4"> <?php echo e($tarif->percent); ?>%</div>
                        <div class="font-italic"><?php echo e($tarif->description); ?></div>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Минимальная инвестиция:  <?php echo e($tarif->min); ?>$</li>
                        <li class="list-group-item">Максимальная инвестиция:  <?php echo e($tarif->max); ?>$</li>
                        <li class="list-group-item">Период инвестиции:  <?php echo e($tarif->hour); ?>ч.</li>
                        <li class="list-group-item">
                            <?php if(\Illuminate\Support\Facades\Auth::user()): ?>
                              <a href="<?php echo e(route('buy', ['id' => $tarif->id])); ?>" class="btn btn-primary">Инвестировать</a>
                            <?php else: ?>
                               <p style="color:red">* Для покупки этого тарифа необходима авторизация</p>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>