<?php $__env->startSection('content'); ?>

<div class="container">
    <h1 class="my-4"><?php echo e($message); ?></h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>